
package javabai8;

import java.util.Scanner;

public class HINHVUONG implements HINH{
    protected int x;
    
    public HINHVUONG(){
    }
    public HINHVUONG(int x) {
        this.x = x;
    }
        public HINHVUONG(HINHVUONG obj) {
        this.x = obj.x;
    }
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }
    @Override
    public double calcArea(){ return x*x; }
    @Override
    public double calcPerimeter() { return 4*x;}
    @Override
    public void Input(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap do dai canh hinh vuong: ");
        x = scanner.nextInt();
    }
    public void Output(){
        System.out.println("Hinh vuong co canh: " + x);
        System.out.println("Dien tich hinh vuong: " + calcArea());
        System.out.println("Chu vi hinh vuong: " + calcPerimeter());
    }
  
}
