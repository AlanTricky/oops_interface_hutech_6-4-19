
package javabai8;

import java.util.ArrayList;
import java.util.Scanner;

public final class QUANLY{
    ArrayList <HINH> dsht = new ArrayList<>();
    ArrayList <HINH> dshv = new ArrayList<>();
    ArrayList <HINH> dshcn = new ArrayList<>();
    HINH h;
    int n;
    Scanner scanner = new Scanner(System.in);
    int Menu(){
        System.out.println("1.Nhap Hinh Tron: ");
        System.out.println("2.Nhap Hinh Vuong: ");
        System.out.println("3.Nhap Hinh Chu Nhat: ");
        System.out.println("4.Xuat Chu Vi, Dien Tich Hinh Tron: ");
        System.out.println("5.Xuat Chu Vi, Dien Tich Hinh Vuong: ");
        System.out.println("6.Xuat Chu Vi, Dien Tich Hinh Chu Nhat: ");
        System.out.println("0.Thoat: ");
        n = scanner.nextInt();
        return n;
    }
    public QUANLY(){
        while(true){
            switch(Menu()){
                case 1:
                    h = new HINHTRON();
                    h.Input();
                    dsht.add(h);
                break;
                case 2:
                    h = new HINHVUONG();
                    h.Input();
                    dshv.add(h);
                break;
                case 3:
                    h = new HINHCN();
                    h.Input();
                    dshcn.add(h);
                break;
                case 4:
                    dsht.forEach((ds) -> {
                        ds.Output();
            });
                break;
                case 5:
                    dshv.forEach((ds) -> {
                        ds.Output();
            });
                break;
                case 6:
                    dshcn.forEach((ds) -> {
                        ds.Output();
            });
                break;
            default: 
                    System.out.println("Thoat chuong trinh.");
                    System.exit(0);
            }
        }
    }
}

