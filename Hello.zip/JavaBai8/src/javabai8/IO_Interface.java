
package javabai8;

public interface IO_Interface {
    public void Input();
    public void Output();
}
