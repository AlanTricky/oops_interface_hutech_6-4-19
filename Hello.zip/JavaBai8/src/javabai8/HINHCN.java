
package javabai8;

import java.util.Scanner;

public class HINHCN implements HINH{
    protected int x,y;
    public HINHCN(){
        
    }

    public HINHCN(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
        public HINHCN(HINHCN obj) {
        this.x = obj.x;
        this.y = obj.y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
      
    @Override
    public double calcArea(){ return (x+y)*2; }
    @Override
    public double calcPerimeter() { return x*y;}
    
    @Override
    public void Input(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap chieu dai hinh chu nhat: ");
        x = scanner.nextInt();
        System.out.println("Nhap chieu rong hinh chu nhat: ");
        y = scanner.nextInt();
    }
    @Override
    public void Output(){
        System.out.println("Hinh chu nhat co chieu dai  x = " +
        x + " va chieu rong y = " + y);
        System.out.println("Dien tich hinh chu nhat: " + calcArea());
        System.out.println("Chu vi hinh chu nhat: " + calcPerimeter());
    }
}
