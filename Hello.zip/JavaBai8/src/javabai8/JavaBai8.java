
package javabai8;

public class JavaBai8 {

    public static void main(String[] args) {
        QUANLY q = new QUANLY();
               
    }
    
}
