package javabai8;

import java.util.Scanner;

public class HINHTRON implements HINH{
    protected int r;
    
    public HINHTRON(){
        
    }
    public HINHTRON(int r) {
        this.r = r;
    }
    public HINHTRON(HINHTRON obj) {
        this.r = obj.r;
    }
    
    @Override
    public double calcArea(){ return pi*r*r; }
    @Override
    public double calcPerimeter() { return pi*2*r;}
    
    @Override
    public void Input(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap ban kinh hinh tron: ");
        r = scanner.nextInt();
    }
    @Override
    public void Output(){
        System.out.println("Hinh tron co ban kinh: " + r);
        System.out.println("Dien tich hinh tron: " + calcArea());
        System.out.println("Chu vi hinh tron: " + calcPerimeter());
    }
}
