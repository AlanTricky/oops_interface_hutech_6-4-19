/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javabai8;

public interface HINH {
    final public double pi= 3.14;
    final public double Pi= 3.14;
    public double calcArea();
    public double calcPerimeter();
    public void Input();

    public void Output();
}
